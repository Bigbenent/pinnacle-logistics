<?php

define('SMTP_HOST', 'mail.pinnacle-wealthwayz.com');
define('SMTP_USER', 'support@pinnacle-wealthwayz.com');
define('SMTP_PASS', 'Godisgood100$'); // Change this and keep it safe
define('SMTP_PORT', 465);
define('SMTP_SECURE', 'ssl');
?>

<?php
define('SMTP_HOST', 'mtl101.truehost.cloud');
define('SMTP_USER', 'support@pinnaclelogistics.com');
define('SMTP_PASS', 'Godisgood100$'); // Change this and keep it safe
define('SMTP_PORT', 465);
define('SMTP_SECURE', 'ssl');
?>
